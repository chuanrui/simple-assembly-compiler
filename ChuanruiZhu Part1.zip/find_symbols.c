#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
 * These are the global variables that you need to populate in the functions below.
 * Do not change these variables' names or types!
 */
char* function_name;
char* parameter_names[10];
char* variable_names[10];

// declaration for helper function to reset global variables
void reset();


/*
 * This is the function you need to implement for Part 1.
 * You must NOT change its signature! 
 */
int parse_function_header(char* header) {
  if (header == NULL) return -1;

  // clean up the global variables - do not remove this line!
  reset();

  // WRITE THE REST OF THIS FUNCTION!
    char* copy_header = malloc(strlen(header)*sizeof(char)+1);
    strcpy(copy_header, header);
    char* token;
    char* delim = {"(){} ,"};
    strtok(copy_header, delim);
    token = strtok(NULL, delim);
    function_name = malloc(strlen(token)*sizeof(char)+1);
    strcpy(function_name, token);
    int i = 0;
    while(i < 10){
        token = strtok(NULL, delim);
        token = strtok(NULL, delim);
        if(token == NULL){
            break;
        }
        parameter_names[i] = malloc(strlen(token)*sizeof(char)+1);
        strcpy(parameter_names[i], token);
        i++;
    }
    free(copy_header);
  // Be sure to return the correct value.
  return 1;
}

/*
 * This is the function you need to implement for Part 1.
 * You must NOT change its signature! 
 */
int parse_line(char* line) {
  if (line == NULL) return -1;
  // clean up the global variables - do not remove this line!
  reset();

  // WRITE THE REST OF THIS FUNCTION!
    char* copy_line = malloc(strlen(line)*sizeof(char)+1);
    strcpy(copy_line, line);
    char* token;
    char* delim = {"+ ;{}"};
    token = strtok(copy_line, delim);
    token = strtok(NULL, delim);
    if(token == NULL) return -1;
    int i = 0;
    while(i < 10){
        if(strcmp(token,"=")==0){
            token = strtok(NULL, delim);
            while(strcmp(token,",")!=0){//find "," if there is no "," end loop
                token = strtok(NULL, delim);
                if(token == NULL)break;
            }
            if(token == NULL)break;
            token = strtok(NULL,delim);
        }
        if(token == NULL)break;
        variable_names[i] = malloc(strlen(token)*sizeof(char)+1);
        strcpy(variable_names[i], token);
        token = strtok(NULL, delim);
        if(token == NULL)break;
        if(strcmp(token,",")==0){
            token = strtok(NULL, delim);
        }
        i++;
    }
    //printf("%s\n", "end function");
    free(copy_line);
  // Be sure to return the correct value.
  return 1;

}


/*
 * This helper function resets the global variables so we can 
 * check them when grading your assignment.
 * You may change this function as needed, e.g. to free memory.
 */
void reset() {
    free(function_name);
  function_name = NULL;
  int i;
  for (i = 0; i < 10; i++) {
      free(parameter_names[i]);
    parameter_names[i] = NULL;
  }
  for (i = 0; i < 10; i++) {
      free(variable_names[i]);
    variable_names[i] = NULL;
  }
}

