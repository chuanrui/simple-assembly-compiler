#include <stdio.h>
#include <string.h>
#include <stdlib.h>

extern int parse_function_header(char*);
extern int parse_line(char*);
extern char* function_name;
extern char* parameter_names[10];
extern char* variable_names[10];

/*
 * THIS IS THE STARTER CODE FOR PART 2
 */

typedef struct Node node;

struct Node{
    char* name_symbol;
    int value_offset;
    node* next;
};

node* head = NULL;

int add_symbol(char* symbol, int offset) {
  // IMPLEMENT THIS IN STEP 1
    if(symbol == NULL){
        return -1;
    }
    node* n = head;
    while(n!=NULL){
        if(strcmp(n->name_symbol, symbol) == 0){
            //printf("%s\n","failed added");
            return 0;
        }
        n = n->next;
    }
    node* new = malloc(sizeof(node));
    //////
    new->name_symbol = malloc(sizeof(symbol));
    strcpy(new->name_symbol, symbol);
    //new->name_symbol = symbol;
    new->value_offset = offset;
    new->next = head;
    head = new;
    //printf("%d\n", head->value_offset);
    //printf("%s\n","success added");
    return 1;
}

int get_offset(char* symbol, int* offset) {
  // IMPLEMENT THIS IN STEP 1
    if(symbol == NULL || offset == NULL){
        return -1;
    }
    node* n = head;
    while(n!=NULL){
        if(strcmp(n->name_symbol, symbol) == 0){
            *offset = n->value_offset;
            return 1;
        }
        n=n->next;
    }
    return 0;
}

void clear() {
  // IMPLEMENT THIS IN STEP 1
    while(head!=NULL){
        node* n = head;
        head = head->next;
        free(n);
    }
}

int populate_symbol_table(char* filename) {
  // IMPLEMENT THIS IN STEP 2
    if(filename == NULL){
        return -1;
    }
    clear();
    FILE* thefile = fopen(filename,"r");
    if(thefile == NULL){
        return -1;
    }
    char* line = malloc(100*sizeof(char)+1);
    fgets(line, 100, thefile);
    parse_function_header(line);
    free(line);//try
    int i = 0, k = 0, j = 0;
    while(parameter_names[i]!=NULL){
        if(add_symbol(parameter_names[i], k+4)==1){
            k++;
        }
        //printf("now head is %s\n", head->name_symbol);
        i++;
    }
    i = 0;
    line = malloc(100*sizeof(char)+1);
    while(fgets(line, 100, thefile)!=NULL){
        j = 0;
        //printf("%s with length of %d\n",line, strlen(line));
        parse_line(line);
        free(line);//try
        line = malloc(100*sizeof(char)+1);//try
        while(variable_names[j]!=NULL){
            if(add_symbol(variable_names[j], 0 - i)==1){
                i++;
            }
            //printf("now head is %s\n", head->name_symbol);
            j++;
        }
    }
    free(line);
    fclose(thefile);
    return 1;
}
