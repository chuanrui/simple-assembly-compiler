#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern int parse_function_header(char*);
extern int parse_line(char*);
extern int add_symbol(char*, int);
extern int get_offset(char*, int*);
extern int populate_symbol_table(char*);

/*
 * THIS IS THE STARTER CODE FOR PART 3
 */
int main(int argc, char* argv[]) {
 
  if (argc < 2) {
    printf("Usage: compiler [input file]\n");
    exit(1);
  }

  char* filename = argv[1];
 
  // first, try to build the symbol table
  if (populate_symbol_table(filename) == 1) {
    // IMPLEMENT PART 3 HERE
      FILE* thefile = fopen(filename,"r");
      if(thefile == NULL){
          return -1;
      }
      FILE* newfile = fopen(strcat(strtok(filename, "."), ".lc4"), "w+");
      char* val_1, *val_2, *val_3;
      char* line = malloc(100*sizeof(char)+1);
      char* token;
      char* delim = {"+= ;\n"};
      int offset = -1000, j = 2;
      fgets(line, 100, thefile);
      free(line);
      line = malloc(100*sizeof(char)+1);
      while(fgets(line, 100, thefile)!=NULL){
          if(*line == '}') break;
          printf("; %s", line);
          fprintf(newfile, "; %s", line);
          token = strtok(line, delim);
          //handle int declaration
          if(strcmp(token, "int")==0){
              while(token!=NULL){
                  token = strtok(NULL, delim);
                  val_1 = malloc(strlen(token)*sizeof(char)+1);
                  strcpy(val_1, token);
                  token = strtok(NULL, delim);
                  if(token == NULL) break;
                  if(strcmp(token, ",")==0){
                      free(val_1);
                  }
                  else{
                      val_2 = malloc(strlen(token)*sizeof(char)+1);
                      strcpy(val_2, token);
                      token = strtok(NULL, delim);
                      if(token == NULL||strcmp(token, ",")==0){
                          //val_1 = val_2
                          //val_2 is number
                          if(*val_2>='0'&&*val_2<='9'){
                              printf("AND R0, R0, %d\n", 0);
                              fprintf(newfile, "AND R0, R0, %d\n", 0);
                              printf("ADD R0, R0, %d\n", atoi(val_2));
                              fprintf(newfile, "ADD R0, R0, %d\n", atoi(val_2));
                              get_offset(val_1, &offset);
                              if(offset == -1000){
                                  printf("line %d, %s has not been declared!\n", j, val_1);
                                  return 0;
                              }
                          }
                          //val_2 is variable
                          else{
                              get_offset(val_2, &offset);
                              if(offset == -1000){
                                  printf("line %d, %s has not been declared!\n", j, val_2);
                                  return 0;
                              }
                              printf("LDR R0, FP, %d\n", offset);
                              fprintf(newfile, "LDR R0, FP, %d\n", offset);
                              offset = -1000;
                              get_offset(val_1, &offset);
                              if(offset == -1000){
                                  printf("line %d, %s has not been declared!\n", j, val_1);
                                  return 0;
                              }
                          }
                          printf("STR R0, FP, %d\n", offset);
                          fprintf(newfile, "STR R0, FP, %d\n", offset);
                          offset = -1000;
                          free(val_1);
                          free(val_2);
                      }
                      else{
                          //val_1 = val_2+val_3+....
                          //val_2 is number
                          if(*val_2>='0'&&*val_2<='9'){
                              printf("AND R0, R0, %d\n", 0);
                              fprintf(newfile, "AND R0, R0, %d\n", 0);
                              printf("ADD R0, R0, %d\n", atoi(val_2));
                              fprintf(newfile, "ADD R0, R0, %d\n", atoi(val_2));
                          }
                          //val_2 is variable
                          else{
                              get_offset(val_2, &offset);
                              if(offset == -1000){
                                  printf("line %d, %s has not been declared!\n", j, val_2);
                                  return 0;
                              }
                              printf("LDR R0, FP, %d\n", offset);
                              fprintf(newfile, "LDR R0, FP, %d\n", offset);
                              offset = -1000;
                          }
                          while(strcmp(token, ",")!=0){                             
                              val_3 = malloc(strlen(token)*sizeof(char)+1);
                              strcpy(val_3, token);
                              //val_3 is number
                              if(*val_3>='0'&&*val_3<='9'){
                                  printf("AND R1, R1, %d\n", 0);
                                  fprintf(newfile, "AND R1, R1, %d\n", 0);
                                  printf("ADD R1, R1, %d\n", atoi(val_3));
                                  fprintf(newfile, "ADD R1, R1, %d\n", atoi(val_3));
                                  printf("ADD R0, R0, R1\n");
                                  fprintf(newfile, "ADD R0, R0, R1\n");
                              }
                              //val_3 is variable
                              else{
                                  get_offset(val_3, &offset);
                                  if(offset == -1000){
                                      printf("line %d, %s has not been declared!\n", j, val_3);
                                      return 0;
                                  }
                                  printf("LDR R1, FP, %d\n", offset);
                                  fprintf(newfile, "LDR R1, FP, %d\n", offset);
                                  offset = -1000;
                                  printf("ADD R0, R0, R1\n");
                                  fprintf(newfile, "ADD R0, R0, R1\n");
                              }
                              free(val_3);
                              token = strtok(NULL, delim);
                              if(token == NULL) break;
                          }
                          get_offset(val_1, &offset);
                          if(offset == -1000){
                              printf("line %d, %s has not been declared!\n", j, val_1);
                              return 0;
                          }
                          printf("STR R0, FP, %d\n", offset);
                          fprintf(newfile, "STR R0, FP, %d\n", offset);
                          offset = -1000;
                          free(val_1);
                          free(val_2);
                      }
                  }
              }
          }
          //handle return
          else if(strcmp(token, "return")==0){
              token = strtok(NULL, delim);
              val_1 = malloc(strlen(token)*sizeof(char)+1);
              strcpy(val_1, token);
              token = strtok(NULL, delim);
              if(token!=NULL){
                  //return val_1 + val_2+......
                  //val_1 is number
                  if(*val_1>='0'&&*val_1<='9'){
                      printf("AND R0, R0, %d\n", 0);
                      fprintf(newfile, "AND R0, R0, %d\n", 0);
                      printf("ADD R0, R0, %d\n", atoi(val_1));
                      fprintf(newfile, "ADD R0, R0, %d\n", atoi(val_1));
                  }
                  //val_1 is variable
                  else{
                      get_offset(val_1, &offset);
                      if(offset == -1000){
                          printf("line %d, %s has not been declared!\n", j, val_1);
                          return 0;
                      }
                      printf("LDR R0, FP, %d\n", offset);
                      fprintf(newfile, "LDR R0, FP, %d\n", offset);
                      offset = -1000;
                  }
                  while(strcmp(token, ",")!=0){
                      val_2 = malloc(strlen(token)*sizeof(char)+1);
                      strcpy(val_2, token);
                      //val_2 is number
                      if(*val_2>='0'&&*val_2<='9'){
                          printf("AND R1, R1, %d\n", 0);
                          fprintf(newfile, "AND R1, R1, %d\n", 0);
                          printf("ADD R1, R1, %d\n", atoi(val_2));
                          fprintf(newfile, "ADD R1, R1, %d\n", atoi(val_2));
                          printf("ADD R0, R0, R1\n");
                          fprintf(newfile, "ADD R0, R0, R1\n");
                      }
                      //val_2 is variable
                      else{
                          get_offset(val_2, &offset);
                          if(offset == -1000){
                              printf("line %d, %s has not been declared!\n", j, val_2);
                              return 0;
                          }
                          printf("LDR R1, FP, %d\n", offset);
                          fprintf(newfile, "LDR R1, FP, %d\n", offset);
                          offset = -1000;
                          printf("ADD R0, R0, R1\n");
                          fprintf(newfile, "ADD R0, R0, R1\n");
                      }
                      free(val_2);
                      token = strtok(NULL, delim);
                      if(token == NULL) break;
                  }
                  printf("STR R0, FP, %d\n", 3);
                  fprintf(newfile, "STR R0, FP, %d\n", 3);
                  free(val_1);
              }
              else{
                  //return val_1
                  get_offset(val_1, &offset);
                  if(offset == -1000){
                      printf("line %d, %s has not been declared!\n", j, val_1);
                      return 0;
                  }
                  printf("LDR R0, FP, %d\n", offset);
                  fprintf(newfile, "LDR R0, FP, %d\n", offset);
                  offset = -1000;
                  printf("STR R0, FP, %d\n", 3);
                  fprintf(newfile, "STR R0, FP, %d\n", 3);
                  free(val_1);
              }
          }
          //handle assignment
          else{
              while(token!=NULL){
                  val_1 = malloc(strlen(token)*sizeof(char)+1);
                  strcpy(val_1, token);
                  token = strtok(NULL, delim);
                  val_2 = malloc(strlen(token)*sizeof(char)+1);
                  strcpy(val_2, token);
                  token = strtok(NULL, delim);
                  if(token == NULL||strcmp(token, ",")==0){
                      //val_1 = val_2
                      //val_2 is number
                      if(*val_2>='0'&&*val_2<='9'){
                          printf("AND R0, R0, %d\n", 0);
                          fprintf(newfile, "AND R0, R0, %d\n", 0);
                          printf("ADD R0, R0, %d\n", atoi(val_2));
                          fprintf(newfile, "ADD R0, R0, %d\n", atoi(val_2));
                          get_offset(val_1, &offset);
                          if(offset == -1000){
                              printf("line %d, %s has not been declared!\n", j, val_1);
                              return 0;
                          }
                      }
                      //val_2 is variable
                      else{
                          get_offset(val_2, &offset);
                          if(offset == -1000){
                              printf("line %d, %s has not been declared!\n", j, val_2);
                              return 0;
                          }
                          printf("LDR R0, FP, %d\n", offset);
                          fprintf(newfile, "LDR R0, FP, %d\n", offset);
                          offset = -1000;
                          get_offset(val_1, &offset);
                          if(offset == -1000){
                              printf("line %d, %s has not been declared!\n", j, val_1);
                              return 0;
                          }
                      }
                      printf("STR R0, FP, %d\n", offset);
                      fprintf(newfile, "STR R0, FP, %d\n", offset);
                      offset = -1000;
                      free(val_1);
                      free(val_2);
                  }
                  else{
                      //val_1 = val_2+val_3+......
                      //val_2 is number
                      if(*val_2>='0'&&*val_2<='9'){
                          printf("AND R0, R0, %d\n", 0);
                          fprintf(newfile, "AND R0, R0, %d\n", 0);
                          printf("ADD R0, R0, %d\n", atoi(val_2));
                          fprintf(newfile, "ADD R0, R0, %d\n", atoi(val_2));
                      }
                      //val_2 is variable
                      else{
                          get_offset(val_2, &offset);
                          if(offset == -1000){
                              printf("line %d, %s has not been declared!\n", j, val_2);
                              return 0;
                          }
                          printf("LDR R0, FP, %d\n", offset);
                          fprintf(newfile, "LDR R0, FP, %d\n", offset);
                          offset = -1000;
                      }
                      while(strcmp(token, ",")!=0){
                          val_3 = malloc(strlen(token)*sizeof(char)+1);
                          strcpy(val_3, token);
                          //val_3 is number
                          if(*val_3>='0'&&*val_3<='9'){
                              printf("AND R1, R1, %d\n", 0);
                              fprintf(newfile, "AND R1, R1, %d\n", 0);
                              printf("ADD R1, R1, %d\n", atoi(val_3));
                              fprintf(newfile, "ADD R1, R1, %d\n", atoi(val_3));
                              printf("ADD R0, R0, R1\n");
                              fprintf(newfile, "ADD R0, R0, R1\n");
                          }
                          //val_3 is variable
                          else{
                              get_offset(val_3, &offset);
                              if(offset == -1000){
                                  printf("line %d, %s has not been declared!\n", j, val_3);
                                  return 0;
                              }
                              printf("LDR R1, FP, %d\n", offset);
                              fprintf(newfile, "LDR R1, FP, %d\n", offset);
                              offset = -1000;
                              printf("ADD R0, R0, R1\n");
                              fprintf(newfile, "ADD R0, R0, R1\n");
                          }
                          free(val_3);
                          token = strtok(NULL, delim);
                          if(token == NULL) break;
                      }
                      token = strtok(NULL, delim);
                      get_offset(val_1, &offset);
                      if(offset == -1000){
                          printf("line %d, %s has not been declared!\n", j, val_1);
                          return 0;
                      }
                      printf("STR R0, FP, %d\n", offset);
                      fprintf(newfile, "STR R0, FP, %d\n", offset);
                      offset = -1000;
                      free(val_1);
                      free(val_2);
                  }
              }
          }
          free(line);
          line = malloc(100*sizeof(char)+1);
          j++;
      }
      free(line);
      fclose(newfile);
      fclose(thefile);
  }
  return 0;
}
