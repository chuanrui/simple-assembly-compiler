#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
 * These are the global variables that you need to populate in the functions below.
 * Do not change these variables' names or types!
 */
char* function_name;
char* parameter_names[10];
char* variable_names[10];
// declaration for helper function to reset global variables
void reset();

typedef struct Node node_1;

struct Node{
    char* check_token;
    node_1* next;
};
//my own helper function
node_1* append_node();
node_1* head_1 = NULL;

/*
 * This is the function you need to implement for Part 1.
 * You must NOT change its signature! 
 */
int parse_function_header(char* header) {
  if (header == NULL) return -1;

  // clean up the global variables - do not remove this line!
  reset();

  // WRITE THE REST OF THIS FUNCTION!
  //check if legal, first divide header into linked list by space
    char* check_header = malloc(strlen(header)*sizeof(char)+1);
    strcpy(check_header, header);
    char* check_delim = {" "};
    char* temp_token;
    node_1* temp_node;
    head_1 = malloc(sizeof(node_1));
    head_1->check_token = strtok(check_header, check_delim);
    head_1->next = NULL;
    temp_token = head_1->check_token;
    temp_node = head_1;
    while(temp_token!=NULL){
        temp_token = strtok(NULL, check_delim);
        temp_node = append_node(temp_token, temp_node);
    }
    node_1* n = head_1;
    node_1* m;
  //after dividing, check function name
  //if header begin with int or void
    if(strcmp(head_1->check_token,"int")==0||strcmp(head_1->check_token,"void")==0){
        //must have function name
        if(strcmp(head_1->next->check_token,"(")==0){
            while(n!=NULL){
                m = n;
                n = n->next;
                free(m);
            }
            free(check_header);
            return 0;
        }
        //if it is not ( after function name, return 0
        if(strcmp(head_1->next->next->check_token,"(")!=0){
            while(n!=NULL){
                m = n;
                n = n->next;
                free(m);
            }
            free(check_header);
            return 0;
        }
    }
    //if header begin with nothing
    else if(strcmp(head_1->next->check_token,"(")!=0){
        while(n!=NULL){
            m = n;
            n = n->next;
            free(m);
        }
        free(check_header);
        return 0;
    }
  //function name checked, set head to  "("
    while(n!=NULL){
        if(strcmp(n->check_token,"(")==0){
            head_1 = n;
            break;
        }
        m = n;
        n = n->next;
        free(m);
    }
    //while header end with ), exit
    while(strcmp(head_1->next->check_token,")")!=0){
        //argument must start with int
        if(strcmp(head_1->next->check_token,"int")!=0){
            while(n!=NULL){
                m = n;
                n = n->next;
                free(m);
            }
            free(check_header);
            return 0;
        }
        //mutiple argument
        if(strcmp(head_1->next->next->next->check_token,")")!=0){
            //must separate with comma
            if(strcmp(head_1->next->next->next->check_token,",")!=0){
                while(n!=NULL){
                    m = n;
                    n = n->next;
                    free(m);
                }
                free(check_header);
                return 0;
            }
        }
        //variables cannot be int or vdid
        if(strcmp(head_1->next->next->check_token, "int")==0||strcmp(head_1->next->next->check_token, "void")==0||strcmp(head_1->next->next->check_token,"return")==0){
            while(n!=NULL){
                m = n;
                n = n->next;
                free(m);
            }
            free(check_header);
            return 0;
        }
        //variables can not start with number
        if(*(head_1->next->next->check_token)<='9'&&*(head_1->next->next->check_token)>='0'){
            while(n!=NULL){
                m = n;
                n = n->next;
                free(m);
            }
            free(check_header);
            return 0;
        }
        //move head to next argument
        head_1 = head_1->next->next->next;
        m = n;
        n = n->next;
        free(m);
        m = n;
        n = n->next;
        free(m);
        m = n;
        n = n->next;
        free(m);
        if(strcmp(head_1->check_token,")")==0) break;
    }
  //when code reaches here means check passed, free linked list and check_header
    while(n!=NULL){
        m = n;
        n = n->next;
        free(m);
    }
    free(check_header);
    char* copy_header = malloc(strlen(header)*sizeof(char)+1);
    strcpy(copy_header, header);
    char* token;
    char* delim = {"(){} ,\n"};
    strtok(copy_header, delim);
    token = strtok(NULL, delim);
    function_name = malloc(strlen(token)*sizeof(char)+1);
    strcpy(function_name, token);
    int i = 0;
    while(i < 10){
        token = strtok(NULL, delim);
        token = strtok(NULL, delim);
        if(token == NULL){
            break;
        }
        parameter_names[i] = malloc(strlen(token)*sizeof(char)+1);
        strcpy(parameter_names[i], token);
        i++;
    }
    free(copy_header);
  // Be sure to return the correct value.
  return 1;
}

/*
 * This is the function you need to implement for Part 1.
 * You must NOT change its signature! 
 */
int parse_line(char* line) {
  if (line == NULL) return -1;
  // clean up the global variables - do not remove this line!
  reset();

  // WRITE THE REST OF THIS FUNCTION!
  //check if legal, first divide line into linked list by space
    char* check_line = malloc(strlen(line)*sizeof(char)+1);
    strcpy(check_line, line);
    char* check_delim = {" \n"};
    char* temp_token;
    node_1* temp_node;
    head_1 = malloc(sizeof(node_1));
    head_1->check_token = strtok(check_line, check_delim);
    head_1->next = NULL;
    temp_token = head_1->check_token;
    temp_node = head_1;
    while(temp_token!=NULL){
        temp_token = strtok(NULL, check_delim);
        temp_node = append_node(temp_token, temp_node);
    }
    node_1* n = head_1;
    node_1* m;
    int flag = 0;
  //dividing done, first check if it ends with semicolon
    while(n!=NULL){
        if(strcmp(head_1->check_token,"}")==0){
            flag = 1;
            break;
        }
        if(strcmp(n->check_token,";")==0){
            if(n->next->check_token==NULL){
                flag = 1;
                break;
            }
        }
        n=n->next;
    }
    n = head_1;
    if(flag == 0){
        while(n!=NULL){
            m = n;
            n = n->next;
            free(m);
        }
        free(check_line);
        return 0;
    }
  //check declaration
  //meet semicolon, continue
    while(strcmp(head_1->check_token,";")!=0){
        //meet {, while loop end
        if(*(head_1->check_token)=='}') break;
        //declaration
        if(strcmp(head_1->check_token,"int")==0){
            //must be variable after int
            if(strcmp(head_1->next->check_token,"=")==0||strcmp(head_1->next->check_token,"+")==0||strcmp(head_1->next->check_token,"int")==0||strcmp(head_1->next->check_token,"return")==0||strcmp(head_1->next->check_token,"void")==0){
                while(n!=NULL){
                    m = n;
                    n = n->next;
                    free(m);
                }
                free(check_line);
                printf("%s\n", "fail 1");
                return 0;
            }
            //must not start with number
            if(*(head_1->next->check_token)>='0'&&*(head_1->next->check_token)<='9'){
                while(n!=NULL){
                    m = n;
                    n = n->next;
                    free(m);
                }
                free(check_line);
                printf("%s\n", "fail 2");
                return 0;
            }
        //move head to first variable
            head_1 = head_1->next;
            free(n);
            n = head_1;
            while(strcmp(head_1->check_token,";")!=0){
                //must followed by equal comma or semicolon
            if(strcmp(head_1->next->check_token,"=")!=0&&strcmp(head_1->next->check_token,",")!=0&&strcmp(head_1->next->check_token,";")!=0){
                while(n!=NULL){
                    m = n;
                    n = n->next;
                    free(m);
                }
                free(check_line);
                printf("%s\n", "fail 3");
                return 0;
            }
                //if it is initialization
            if(strcmp(head_1->next->check_token,"=")==0){
                //must followed by + or comma and semicolon
                if(strcmp(head_1->next->next->next->check_token,"+")!=0&&strcmp(head_1->next->next->next->check_token,",")!=0&&strcmp(head_1->next->next->next->check_token,";")!=0){
                    while(n!=NULL){
                        m = n;
                        n = n->next;
                        free(m);
                    }
                    free(check_line);
                    printf("%s\n", "fail 4");
                    return 0;
                }
                //if it has +, move head to next two char to see if it is still + or , or ;
                if(strcmp(head_1->next->next->next->check_token,"+")==0){
                    head_1 = head_1->next->next->next;
                    m = n;
                    free(m);
                    n = n->next;
                    m = n;
                    free(m);
                    n = n->next;
                    m = n;
                    free(m);
                    n = n->next;
                    //if it is still +, keep moving
                    while(strcmp(head_1->check_token,"+")==0){
                        head_1 = head_1->next->next;
                        m = n;
                        free(m);
                        n = n->next;
                        m = n;
                        free(m);
                        n = n->next;
                    }
                    //if it is semicolon, break
                    if(*(head_1->check_token)==';') break;
                    if(strcmp(head_1->check_token, ",")!=0){
                        while(n!=NULL){
                            m = n;
                            n = n->next;
                            free(m);
                        }
                        free(check_line);
                        printf("%s\n", "fail 11");
                        return 0;
                    }
                    //move to comma or semicolon, continue loop
                    head_1 = head_1->next;
                    m = n;
                    free(m);
                    n = n->next;
                }
                //if it has no +, move to next variable
                else if(strcmp(head_1->next->next->next->check_token,",")==0){
                    head_1 = head_1->next->next->next->next;
                    m = n;
                    free(m);
                    n = n->next;
                    m = n;
                    free(m);
                    n = n->next;
                    m = n;
                    free(m);
                    n = n->next;
                    m = n;
                    free(m);
                    n = n->next;
                }
                //if it has semicolon, move to it
                else if(strcmp(head_1->next->next->next->check_token,";")==0){
                    head_1 = head_1->next->next->next;
                    m = n;
                    free(m);
                    n = n->next;
                    m = n;
                    free(m);
                    n = n->next;
                    m = n;
                    free(m);
                    n = n->next;
                }
            }
            //simple declaration, move to next variable
            else if(strcmp(head_1->next->check_token,",")==0){
                head_1 = head_1->next->next;
                m = n;
                free(m);
                n = n->next;
                m = n;
                free(m);
                n = n->next;
            }
                //if end with semicolon, move to it
            else if(strcmp(head_1->next->check_token,";")==0){
                head_1 = head_1->next;
                m = n;
                free(m);
                n = n->next;
            }
        }
        }
        //return line
        else if(strcmp(head_1->check_token,"return")==0){
            while(strcmp(head_1->next->next->check_token,";")!=0){
                //if it is not semicolon, must be plus
                if(strcmp(head_1->next->next->check_token,"+")!=0){
                    while(n!=NULL){
                        m = n;
                        n = n->next;
                        free(m);
                    }
                    free(check_line);
                    printf("%s\n", "fail 5");
                    return 0;
                }
                //must end with semicolon
                if(strcmp(head_1->next->next->next->next->check_token,";")!=0){
                    while(n!=NULL){
                        m = n;
                        n = n->next;
                        free(m);
                    }
                    free(check_line);
                    printf("%s\n", "fail 6");
                    return 0;
                }
                //move to next plus or semicolon
                head_1 = head_1->next->next;
                m = n;
                free(m);
                n = n->next;
                m = n;
                free(m);
                n = n->next;
            }
            break;
        }
        //assignment
        else {
            //must not followed by = or void
            if(strcmp(head_1->check_token,"=")==0||strcmp(head_1->check_token,"void")==0){
                while(n!=NULL){
                    m = n;
                    n = n->next;
                    free(m);
                }
                free(check_line);
                printf("%s\n", "fail 7");
                return 0;
            }
            //must not start with number
            if(*(head_1->check_token)>='0'&&*(head_1->check_token)<='9'){
                while(n!=NULL){
                    m = n;
                    n = n->next;
                    free(m);
                }
                free(check_line);
                printf("%s\n", "fail 8");
                return 0;
            }
            //must be = after variable
            if(strcmp(head_1->next->check_token,"=")!=0){
                printf("%s\n", head_1->next->check_token);
                while(n!=NULL){
                    m = n;
                    n = n->next;
                    free(m);
                }
                free(check_line);
                printf("%s\n", "fail 9");
                return 0;
            }
            //must be + or , or ; after variable
            if(strcmp(head_1->next->next->next->check_token,"+")!=0&&strcmp(head_1->next->next->next->check_token,",")!=0&&strcmp(head_1->next->next->next->check_token,";")!=0){
                printf("%s\n", head_1->check_token);
                while(n!=NULL){
                    m = n;
                    n = n->next;
                    free(m);
                }
                free(check_line);
                printf("%s\n", "fail 10");
                return 0;
            }
            //if it is +
            if(strcmp(head_1->next->next->next->check_token,"+")==0){
                if(*(head_1->next->next->next->next->next->check_token)==';') break;
                head_1 = head_1->next->next->next->next->next->next;
                m = n;
                free(m);
                n = n->next;
                m = n;
                free(m);
                n = n->next;
                m = n;
                free(m);
                n = n->next;
                m = n;
                free(m);
                n = n->next;
                m = n;
                free(m);
                n = n->next;
                m = n;
                free(m);
                n = n->next;
            }
            //if it is ,
            else if(strcmp(head_1->next->next->next->check_token,",")==0){
                head_1 = head_1->next->next->next->next;
                m = n;
                free(m);
                n = n->next;
                m = n;
                free(m);
                n = n->next;
                m = n;
                free(m);
                n = n->next;
                m = n;
                free(m);
                n = n->next;
            }
            //if it is ;
            else if(strcmp(head_1->next->next->next->check_token,";")==0){
                head_1 = head_1->next->next->next;
                m = n;
                free(m);
                n = n->next;
                m = n;
                free(m);
                n = n->next;
                m = n;
                free(m);
                n = n->next;
            }    
        }
    }
  //when code reaches here means check passed, free linked list and check_header
    while(n!=NULL){
        m = n;
        n = n->next;
        free(m);
    }
    free(check_line);
    if(*line == '}') return -1;
    char* copy_line = malloc(strlen(line)*sizeof(char)+1);
    strcpy(copy_line, line);
    char* token;
    char* delim = {"+ ;{}\n"};
    token = strtok(copy_line, delim);
    token = strtok(NULL, delim);
    if(token == NULL) return -1;
    int i = 0;
    while(i < 10){
        if(strcmp(token,"=")==0){
            token = strtok(NULL, delim);
            while(strcmp(token,",")!=0){//find "," if there is no "," end loop
                token = strtok(NULL, delim);
                if(token == NULL)break;
            }
            if(token == NULL)break;
            token = strtok(NULL,delim);
        }
        if(token == NULL)break;
        variable_names[i] = malloc(strlen(token)*sizeof(char)+1);
        strcpy(variable_names[i], token);
        token = strtok(NULL, delim);
        if(token == NULL)break;
        if(strcmp(token,",")==0){
            token = strtok(NULL, delim);
        }
        i++;
    }
    free(copy_line);
  // Be sure to return the correct value.
  return 1;

}

/*
 * my own helper function
 * add new node at the end of linked list(not at the beginning)
 */
node_1* append_node(char* token, node_1* before){
    node_1* n = malloc(sizeof(node_1));
    n->check_token = token;
    n->next = NULL;
    before->next = n;
    return n;
}

/*
 * This helper function resets the global variables so we can 
 * check them when grading your assignment.
 * You may change this function as needed, e.g. to free memory.
 */
void reset() {
    free(function_name);
  function_name = NULL;
  int i;
  for (i = 0; i < 10; i++) {
      free(parameter_names[i]);
    parameter_names[i] = NULL;
  }
  for (i = 0; i < 10; i++) {
      free(variable_names[i]);
    variable_names[i] = NULL;
  }
}

