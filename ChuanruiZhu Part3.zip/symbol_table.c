#include <stdio.h>
#include <string.h>
#include <stdlib.h>

extern int parse_function_header(char*);
extern int parse_line(char*);
extern char* function_name;
extern char* parameter_names[10];
extern char* variable_names[10];

/*
 * THIS IS THE STARTER CODE FOR PART 2
 */

typedef struct Node node;

struct Node{
    char* name_symbol;
    int value_offset;
    node* next;
};

node* head = NULL;

int add_symbol(char* symbol, int offset) {
  // IMPLEMENT THIS IN STEP 1
    if(symbol == NULL){
        return -1;
    }
    node* n = head;
    //if the symbol already exist, return 0
    while(n!=NULL){
        if(strcmp(n->name_symbol, symbol) == 0){
            return 0;
        }
        n = n->next;
    }
    node* new = malloc(sizeof(node));
    new->name_symbol = malloc(sizeof(symbol));
    strcpy(new->name_symbol, symbol);
    new->value_offset = offset;
    new->next = head;
    head = new;
    return 1;
}

int get_offset(char* symbol, int* offset) {
  // IMPLEMENT THIS IN STEP 1
    if(symbol == NULL || offset == NULL){
        return -1;
    }
    node* n = head;
    //if find the target symbol, change offset
    while(n!=NULL){
        if(strcmp(n->name_symbol, symbol) == 0){
            *offset = n->value_offset;
            return 1;
        }
        n=n->next;
    }
    return 0;
}

void clear() {
  // IMPLEMENT THIS IN STEP 1
    while(head!=NULL){
        node* n = head;
        head = head->next;
        free(n);
    }
}

int populate_symbol_table(char* filename) {
  // IMPLEMENT THIS IN STEP 2
    if(filename == NULL){
        return -1;
    }
    clear();
    FILE* thefile = fopen(filename,"r");
    if(thefile == NULL){
        return -1;
    }
    //create check_line to check if the line begins with int
    char* check_line = malloc(100*sizeof(char)+1);
    //create line to store each line in file
    char* line = malloc(100*sizeof(char)+1);
    fgets(line, 100, thefile);
    parse_function_header(line);
    free(line);
    int i = 0, k = 0, j=2;
    while(parameter_names[i]!=NULL){
        if(add_symbol(parameter_names[i], k+4)==1){
            k++;
        }
        //if variable has been declared, return 0
        else{
            printf("line %d, %s has been declared before!\n",1, parameter_names[i]);
            return 0;
        }
        i++;
    }
    k = 0;
    line = malloc(100*sizeof(char)+1);
    while(fgets(line, 100, thefile)!=NULL){
        strcpy(check_line, line);
        //if the line begins with int, pass
        if(strcmp(strtok(check_line, " "), "int")!=0) continue;
        i = 0;
        parse_line(line);
        free(line);
        line = malloc(100*sizeof(char)+1);
        while(variable_names[i]!=NULL){
            if(add_symbol(variable_names[i], 0 - k)==1){
                k++;
            }
            //if variable has been declared, return 0
            else{
                printf("line %d, %s has been declared before!\n", j, variable_names[i]);
                return 0;
            }
            i++;
        }
        j++;
    }
    free(check_line);
    free(line);
    fclose(thefile);
    return 1;
}
